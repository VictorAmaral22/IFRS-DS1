<?php

namespace App\Controllers;

use App\Models\Items;

class ItemController extends BaseController
{
    public function showRegisterForm()
    {
        return view('formulario');
    }
    public function InsertRegisterForm()
    {
        $nome=$this->request->getVar('nome');
        $idade=$this->request->getVar('idade');
        $descr=$this->request->getVar('descr');
        $data=[
            'nome'=>$nome,
            'idade'=>$idade,
            'descr'=>$descr
        ];
        $model=new Items();
        $inserted=$model->insert_Items($data);
        if($inserted){
            return redirect('/');
        }
        else{
            echo "ERRO";
        }
    }
    public function index(){
        $model=new Items();
        $data=$model->get_Items();
        return view('items-show',['data'=>$data]);
    }
    public function deleteItem($id)
    {
        $model=new Items();
        $removed=$model->delete_Item($id);
        if($removed) return redirect('/');
        else echo "Erro";
    }
    public function showFormEdit($id){
        $model=new Items();
        $data=$model->get_Item($id);
        return view('item-edit',['data'=>$data]);
    }
    public function editItem()
    {
        $data=[
            'id'=>$this->request->getVar('id'),
            'nome'=>$this->request->getVar('nome'),
            'idade'=>$this->request->getVar('idade'),
            'descr'=>$this->request->getVar('descr')
        ];
        $model=new Items();
        $edited=$model->edit_Item($data);
        if($edited) return redirect('/');
        else echo "Erro";
    }
}
