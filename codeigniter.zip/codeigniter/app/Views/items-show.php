<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/css/styles.css">
    <title>Items</title>
</head>
<body>
    <div class="flex-div">
        <table class="table">
            <tr>
                <td colspan="4" style="text-align: center;">
                    ITEMS TABLE
                </td>
                <td colspan="2" style="text-align: center;">
                    <form action="" method="get">
                        <input type="text" name="nome"> <input type="submit" value="🔍" class="input-submit" />
                    </form>
                </td>
            </tr>
            <tr>
                <td>Id</td>
                <td>Nome</td>
                <td>Idade</td>
                <td>Descrição</td>
                <td>Deletar</td>
                <td>Alterar</td>
            </tr>
            <?php
                foreach($data as $row){
                    if(isset($_GET['nome'])) {
                        if(preg_match("/$_GET[nome]/", $row['nome'])) {
                            echo "<tr>";
                            echo "<td>$row[id]</td>";
                            echo "<td>$row[nome]</td>";
                            echo "<td>$row[idade]</td>";
                            echo "<td>$row[descr]</td>";
                            echo "<td><a href=/deleteItem/$row[id]>🗑️</a></td>";
                            echo "<td><a href=/showEditForm/$row[id]>✏️</a></td>";
                            echo "</tr>";
                        }
                    } else {
                        echo "<tr>";
                        echo "<td>$row[id]</td>";
                        echo "<td>$row[nome]</td>";
                        echo "<td>$row[idade]</td>";
                        echo "<td>$row[descr]</td>";
                        echo "<td><a href=/deleteItem/$row[id]>🗑️</a></td>";
                        echo "<td><a href=/showEditForm/$row[id]>✏️</a></td>";
                        echo "</tr>";
                    }
                }
            ?>
        </table>
        <br>
        <div class="button">
            <a href="/showItemForm">Registrar novo</a>
        </div>
    </div>
</body>
</html>